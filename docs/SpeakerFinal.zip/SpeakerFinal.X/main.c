 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/adc/adc.h"
#include "mcc_generated_files/dac/dac1.h"

#define TRASH_FULL_THRESHOLD_RA0  500
#define TRASH_FULL_THRESHOLD_RA1  500

void putch(char c)
{
    (void)c;
}

int main(void)
{
    SYSTEM_Initialize();
    DAC1_Initialize();

    IO_RB3_SetLow();
    IO_RD5_SetLow();
    DAC1_SetOutput(0);

    while (1)
    {
        ADC_ChannelSelect(ADC_CHANNEL_ANA0);
        ADC_ConversionStart();
        while (!ADC_IsConversionDone());
        adc_result_t ra0Value = ADC_ConversionResultGet();

        ADC_ChannelSelect(ADC_CHANNEL_ANA1);
        ADC_ConversionStart();
        while (!ADC_IsConversionDone());
        adc_result_t ra1Value = ADC_ConversionResultGet();

        printf("RA0: %u  RA1: %u\r\n", (unsigned)ra0Value, (unsigned)ra1Value);

        bool buttonPressed = (IO_RD1_GetValue() == 0);

        if (buttonPressed)
        {
            for (uint16_t i = 0; i < 400; i++)
            {
                DAC1_SetOutput(255);
                IO_RD5_SetHigh();
                IO_RB3_SetHigh();
                __delay_us(100);

                DAC1_SetOutput(0);
                IO_RD5_SetLow();
                IO_RB3_SetLow();
                __delay_us(100);
            }
        }
        else
        {
            DAC1_SetOutput(0);
            IO_RD5_SetLow();
            IO_RB3_SetLow();
        }

        __delay_ms(100);
    }

    return 0;
}